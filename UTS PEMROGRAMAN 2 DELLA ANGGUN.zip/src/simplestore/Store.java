/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Della Anggun
 */
package simplestore;

import java.util.ArrayList;

public class Store {
    private ArrayList<Product> products = new ArrayList<>();

    public void addProduct(Product p) {
        // Cegah ID duplikat
        for (Product prod : products) {
            if (prod.getId() == p.getId()) {
                throw new IllegalArgumentException("ID sudah ada!");
            }
        }
        products.add(p);
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public Product findById(int id) {
        for (Product p : products) {
            if (p.getId() == id) return p;
        }
        return null;
    }
}